CLIENT_ID = 'sample-implicit-hemant'
REDIRECT_URL = (
    'https://layla.amazon.com/spa/skill/account-linking-status.html?vendorId=M17X6SNMCM2HNS',
    'https://pitangui.amazon.com/spa/skill/account-linking-status.html?vendorId=M17X6SNMCM2HNS',
    'https://alexa.amazon.co.jp/spa/skill/account-linking-status.html?vendorId=M17X6SNMCM2HNS'
)
RESPONSE_TYPE = 'token'



USERNAME = 'admin'
PASSWORD = 'password'